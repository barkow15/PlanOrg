Event Organizer.pdf: Vores rapport

Kode: Indeholder kilde filerne.
Programmer: Indeholder de 2 programmer 1 til sekret�ren og 1 til facilitatorne
Diagram_bilag: Indeholder diagrammer som der ikke kan vises i rapporten da de er for store.
VisualParadigm: Er inkluderet hvis i �nsker at se de forskellige diagrammer / wireframes direkte i visual paradigm
Javadoc: Indeholder autogenereret "javadoc filer"