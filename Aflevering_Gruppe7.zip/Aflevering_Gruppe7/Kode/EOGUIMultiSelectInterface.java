/**
* Classes that are passed to EOGUIMultiSelect must implement this class to be painted
*/
public interface EOGUIMultiSelectInterface
{
   public String getDisplayName();
}