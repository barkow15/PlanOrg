/**
* The run class, is the start class of the program, where we start the EOManager.
*/
public class Run
{
   public static void main(String[] args)
   {
      new EOManager();
   }
}